project title: A-Z Anime
group name: Sentinels
group number: 19
| Member Names  | Member Emails | Member IDs
| ------------- | ------------- | ------------
| ABINILA SIVA  | asiva017@ucr.edu  | 862333786
| ABHAV PRASAD | apras032@ucr.edu  | 862393833
| NEEHA GAJULA | ngaju002@ucr.edu | 862465751
| ASMA KHAN    |  akhan195@@ucr.edu | 862395414
| KUMAR PRIYAM |  kpriy001@ucr.edu | 862394441