dataset_folder = 'file:///home/abhav/big_data_project/datasets/'
anime_ds = dataset_folder+'anime_no_synopsis.csv'
anime_filtered_ds = dataset_folder+'anime-filtered_no_synopsis.csv'
final_anime_ds = dataset_folder+'final_animedataset.csv'
user_rating_ds = dataset_folder+'user-filtered.csv'
user_ds = dataset_folder+'users-details-2023.csv'
username_rating_ds = dataset_folder+'users-score-2023.csv'

all_paths = [anime_ds, anime_filtered_ds, final_anime_ds, user_rating_ds, user_ds, username_rating_ds]
