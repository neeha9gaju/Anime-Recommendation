RESULT_LIMIT = 10  # this is to limit the search results to 10
